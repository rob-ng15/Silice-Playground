./clangall.sh
./compileall.sh

