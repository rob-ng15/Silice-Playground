#include "PAWSlibrary.h"

int main( void ) {
    INITIALISEMEMORY();

    while(1) {
    }
}
