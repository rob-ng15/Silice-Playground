#include "PAWSlibrary-newlib.h"
#include <stdio.h>

void main( void ) {
    INITIALISEMEMORY();

    while(1) {
        printf("TESTING...");
    }
}
