./compile.sh c/ascii-invaders.c PAWS/INVADERS.PAW
./compile.sh c/asteroids.c PAWS/ASTROIDS.PAW
./compile.sh c/chess.c PAWS/CHESS.PAW
./compile.sh c/demo.c PAWS/DEMO.PAW
./compile.sh c/fractal.c PAWS/FRACTAL.PAW
./compile.sh c/jpeg-test.c PAWS/JPEG.PAW
./compile.sh c/life.c PAWS/LIFE.PAW
./compile.sh c/maze.c PAWS/3DMAZE.PAW
./compile.sh c/smttest.c PAWS/SMT.PAW
./compile.sh c/terminal-test.c PAWS/TERMINAL.PAW
./compile.sh c/tune.c PAWS/TUNE.PAW


