./clang.sh c/ascii-invaders.c PAWS/CLANGI.PAW
./clang.sh c/asteroids.c PAWS/CLANGA.PAW
./clang.sh c/chess.c PAWS/CLANGC.PAW
./clang.sh c/demo.c PAWS/CLANGD.PAW
./clang.sh c/fractal.c PAWS/CLANGF.PAW
./clang.sh c/jpeg-test.c PAWS/CLANGJ.PAW
./clang.sh c/life.c PAWS/CLANGL.PAW
./clang.sh c/maze.c PAWS/CLANGM.PAW
./clang.sh c/smttest.c PAWS/CLANGS.PAW
./clang.sh c/terminal-test.c PAWS/CLANGT.PAW
./clang.sh c/tune.c PAWS/CLANGT2.PAW


